import React, { useState } from "react";
import enrichedMath from "./enrichedMathNew";
import dict from "./EnrichedRecipeNew.json";
import { InputNum } from "./InputNum";
import { SelfHidingRow } from "./SelfHidingRow";

const EnrichedBreadCalc = () => {
  const [recipe, setRecipe] = useState(dict);
  const [amount, setAmount] = useState(1);
  const handleChange = (e) => {
    const { name, valueAsNumber } = e.target;
    // name === "starterHydraton"
    //   ? (recipe["starter"].hydration = valueAsNumber)
    //   : (recipe[name].value = valueAsNumber);
    recipe[name].value = valueAsNumber
    setRecipe({
      ...recipe,
    });
  };
  const bread_table = enrichedMath(
    ...Object.entries(recipe).map(([key,obj])=>obj.value),
    amount
  );
  return (
    <div className="container">
      <h1 className=" my-10 text-center text-sky-700">
        营养面团计算器
      </h1>
      <div className="flex">
        <div className=" w-1/2">
          {Object.entries(recipe).map(([key, obj], index) => (
            <InputNum key={`bread_${key}`} {...obj} onChange={handleChange} />
          ))}

          <InputNum
            label="数量"
            type="number"
            name="amount"
            unit="个"
            value={amount}
            onChange={(e) => setAmount(e.target.valueAsNumber)}
          />
        </div>
        <table className=" w-1/2">
          <thead>
            <tr>
              <td className=" border-b border-gray-400"></td>
              <td className=" border-b border-gray-400">重量</td>
              <td className=" border-b border-gray-400">百分比</td>
            </tr>
          </thead>
          {Object.entries(bread_table).map(([key, obj], index) => (
            <>
              <SelfHidingRow
                key={`table_${key}`}
                title={key}
                unit="克"
                dataTuple={obj}
              />
            </>
          ))}
        </table>
      </div>
      {/* <pre><code>{JSON.stringify(bread_table,null,2)}</code></pre> */}
    </div>
  );
};

export default EnrichedBreadCalc;
