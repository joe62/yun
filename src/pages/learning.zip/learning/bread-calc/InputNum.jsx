import React from 'react'

export const InputNum=({label,unit,hydration,...data})=>(<div className="m-2">
<label className={data.name==='starterHydration'&&`text-xs mr-2 ml-2`} htmlFor="flour">{label} ({unit})</label>
<input
className={`ml-2 w-15 ${data.name==='starterHydration'&&'text-xs w-15 p-1'}`}
  
{...data}
/>

</div>)
