
# Bread Calulator
> sourdough bread and enriched bread


1. https://breadcalculator.com/
2. [bread-calc-react](https://github.com/jclynb/bread-calc-react)
3. [Structure of the Egg](https://web.extension.illinois.edu/eggs/res16-egg.html)
4. [bread](https://github.com/ZeeCoder/bread) [demo](https://sourdough.now.sh/)
5. [headless](https://headlessui.com/)
6. [heroicons](https://heroicons.com/)
7. [heropatterns.com](https://heropatterns.com/)
8. https://codingbeautydev.com/blog/react-get-input-value/


