import React from 'react';
import ToChinese from './toChinese.json'

export const SelfHidingRow = ({ dataTuple, title, unit }) => (dataTuple && dataTuple[0] ? (<>
  <tbody>
    <tr>
      <td className=' uppercase border-b border-gray-400 p-3'>{ToChinese[title]}</td>
      <td className=' border-b border-gray-400 p-3'>{Math.round(dataTuple[0]*100)/100}{unit}</td>
      <td className=' border-b border-gray-400 p-3'>{Math.round(dataTuple[1]*100)/100}%</td>
    </tr>
  </tbody>
</>) : null);
