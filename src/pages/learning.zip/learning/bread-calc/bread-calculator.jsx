import React, { useState } from 'react';


const Form = () => {
  const [formData, setFormData] = useState({
    hydrationLevel: 80,
    flourWeight: 400,
    waterWeight: 320,
    saltWeight: 8,
    starterWeight: 80
  });

  const handleChange = (event)=> {
    const { name, value } = event.target;
    setFormData((prevFormData) => ({
      ...prevFormData,
      [name]: parseInt(value)
    }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const { flourWeight, hydrationLevel } = formData;
    setFormData({
      flourWeight,
      hydrationLevel,
      waterWeight: flourWeight * (hydrationLevel / 100),
      saltWeight: flourWeight * 0.02,
      starterWeight: flourWeight * 0.2
    });
  };

  return (
    <form onSubmit={handleSubmit} className='flex flex-col max-w-lg mx-auto text-blue-900'>
      <h2 className='text-2xl mt-4 font-bold mb-4 text-gray-700'>酸面团配方计算器</h2>
      <div className='mb-4'>
        <label htmlFor='flourWeight' className='block font-bold mb-2'>
          面粉:
        </label>
        <input
          type='number'
          name='flourWeight'
          id='flourWeight'
          value={formData.flourWeight}
          onChange={handleChange}
          className='shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline'
        />
      </div>
      <div className='mb-4'>
        <label htmlFor='hydrationLevel' className='block font-bold mb-2'>
          水合度 (%):
        </label>
        <input
          type='number'
          name='hydrationLevel'
          id='hydrationLevel'
          value={formData.hydrationLevel}
          onChange={handleChange}
          className='shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline'
        />
      </div>
      <button
        type='submit'
        className='items-center bg-blue-900 hover:bg-green-800 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline'
      >
        计算
      </button>
      <div className='mb-4 mt-6'>
        <label htmlFor='waterWeight' className='block font-bold mb-2'>
          水 ({formData.hydrationLevel >= 0 ? formData.hydrationLevel : 0}%):
        </label>
        <input
          type='number'
          name='waterWeight'
          id='waterWeight'
          value={formData.waterWeight}
          readOnly
          className='shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 bg-gray-200 leading-tight focus:outline-none focus:shadow-outline'
        />
      </div>
      <div className='mb-4'>
        <label htmlFor='saltWeight' className='block font-bold mb-2'>
          盐 (2.5%):
        </label>
        <input
          type='number'
          name='saltWeight'
          id='saltWeight'
          value={formData.saltWeight}
          readOnly
          className='shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 bg-gray-200 leading-tight focus:outline-none focus:shadow-outline'
        />
      </div>
      <div className='mb-4'>
        <label htmlFor='starterWeight' className='block font-bold mb-2'>
          酵头 (23%):
        </label>
        <input
          type='number'
          name='starterWeight'
          id='starterWeight'
          value={formData.starterWeight}
          readOnly
          className='shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 bg-gray-200 leading-tight focus:outline-none focus:shadow-outline'
        />
      </div>
    </form>
  );
};

export default Form;