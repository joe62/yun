export default function sourMath(
  flour,
  hydration,
  _salt,
  _yeast,
  starter,
  starterHydration,
  amount
) {
  let starter_flour = starter / (1 + starterHydration / 100);
  let starter_water = starter_flour * (starterHydration / 100);
  //define the weights//
  let flour_total = flour + starter_flour;
  let salt = (flour_total * _salt) / 100; //bread recipes need about 2% salt
  let yeast = (flour_total * _yeast) / 100;
  let water = flour_total * (hydration / 100) - starter_water; //calculates water needed to be added to dough
  let total_water = flour_total * (hydration / 100); //total water from added water + starter
  let total_dough = flour + salt + water + starter + yeast;

  //define the percentages//

  //flour percentages
  let flour_percent = (flour / flour_total) * 100;
  let total_flour_percent = (flour_total / flour_total) * 100;
  //salt
  let salt_percent = (salt / flour_total) * 100;
  //starter percentages
  let starter_flour_percent = (starter_flour / flour_total) * 100;
  let starter_water_percent = (starter_water / flour_total) * 100;
  let yeast_percent = (yeast / flour_total) * 100;
  //water
  let water_percent = (water / flour_total) * 100;
  let total_water_percent = (total_water / flour_total) * 100;
  //dough
  let total_dough_percent = (total_dough / flour_total) * 100;

  //scale//
  if (amount > 1) {
    let scale =
      (amount * total_dough) /
      (flour_percent +
        salt_percent +
        starter_flour_percent +
        yeast_percent +
        starter_water_percent +
        water_percent);

    flour = scale * flour_percent;
    flour_total = scale * total_flour_percent;
    salt = scale * salt_percent;
    starter = scale * starter_flour_percent + scale * starter_water_percent;
    yeast = scale * yeast_percent;
    water = scale * water_percent;
    total_water = scale * total_water_percent;
    total_dough = scale * total_dough_percent;
  }

  //make table store weights and percents
  let data_table = {
    flour: [flour, flour_percent],
    water: [water, water_percent],
    starter: [starter, starter_flour_percent],
    yeast: [yeast, yeast_percent],
    salt: [salt, salt_percent],
    total_flour: [flour_total, total_flour_percent],
    total_water: [total_water, total_water_percent],
    total_dough: [total_dough, total_dough_percent],
  };

  return data_table;
}
