import React from 'react'


const calc=(doughWeight,desiredHydration, starterHydration)=>{
  let flourWeight = doughWeight * (1/(1+(desiredHydration/100)))
  let waterWeight = flourWeight * desiredHydration / 100
   
}

const Input=({data:{key,value:{des,value,unit,disabled}},onChange})=>{
  //console.log(data) 
 return <div className='grid gap-x-[3px] grid-cols-[1fr_2fr]  items-baseline '>
   <label className='text-bread-darkyello text-right' >{des}</label>
   <span className=' inline-grid grid-cols-[1fr_minmax(20px,auto)] items-center text-bread-orage 
    bg-bread-yello focus:bg-bread-darkyello  focus:outline-0 ' >
      <input 
      onChange={onChange} 
      className={`w-full m-[5px] p-0.5 border-0 focus:bg-bread-orage focus:outline-0  font-bold  text-bread-darkyello  bg-bread-yello ${disabled ? 'border-0' :' border-b-2 border-bread-orage'}`}
       type="number" name={key} id={key} defaultValue={value} disabled={disabled} />{unit}</span>
 </div>
}
const SourdoughCalc = () => {

  

  const handleChange=({target:{name,value}})=>{
   console.log({name,value})
  }


  const data = {
    dough:{des: "面团", value: 505, unit: "g",disabled:false},
    hytration:{des:"含水",value: 80,unit:"%",disabled:false},
    flour: { des: "面粉", value: 100, unit: "%" ,disabled:true},
    water: { des: "水", value: 78, unit: "%" ,disabled:true},
    starter: { des: "酵头", value: 20, unit: "%" ,disabled:true},
    salt: { des: "盐 ", value: 2, unit: "%" ,disabled:true},
  };
  return (
    <>
    <header className="w-full py-5 px-0 grid grid-cols-[1fr_150px]">
      <div className="container w-4/5 p-3">
        <h1 className=' text-bread-orage text-4xl text-center my-3 mx-auto font-sans italic font-bold' >酸面团计算器</h1>
      </div>
      <nav className=' text-bread-orage'>
        <a className='mr-2 text-bread-orage' href="?lang=fr">fr</a>
        <a className='mr-2 text-bread-orage'  href="?lang=en">en</a>
        <a className='text-bread-orage' href="?lang=zh">中文</a>
      </nav>
     </header>
    <main className=' w-11/12 rounded my-0 mx-auto bg-bread-yello'>
      <div className="container p-4 w-11/12 ">
        
        {Object.entries(data).map(([key,value])=><Input data={{key,value}} onChange={handleChange} />)}
      </div>
      {/* <main className='container bg-white'>
      <div className="py-12">
          <h2 className="text-2xl font-bold">Underline</h2>
          <div className="">
            <Input data={{dough:'面团',value:505,unit:'克'}} />
            <div className="grid grid-cols-3 gap-2">
            <Input data={{flour:'面粉',value:100,unit:'%'}} />
              <Input data={{water:'水',value:78,unit:'%'}} />
              <Input data={{starter:'酵头',value:20,unit:'%'}} />
              <Input data={{salt:'盐',value:2,unit:'%'}} />
            </div>
          </div>
        </div>
      </main> */}
     
     </main>
    </>
  )
}

export default SourdoughCalc