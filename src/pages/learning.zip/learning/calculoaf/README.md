1. https://github.com/alfrdmalr/calculoaf
2. https://alfrdmalr.github.io/calculoaf/
3. G:\baking\github-baking-calculator\calculoaf
