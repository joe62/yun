import React from 'react'

export const NumberInput = ({id,value,setValue,label,precision,required,enforceBounds,onBlur,displayValue,onInputChange, min,max,allowNegative,...rest}) => {
  return (
    <div>
      <label htmlFor={id}>{label}</label>
      <input
        {...rest}
        required={required}
        type="text"
        inputMode="numeric"
        onChange={onInputChange}
        onBlur={onBlur}
        defaultValue={displayValue}
      />
    </div>
  )
}
