import React from 'react'

export const TextInput = ({label,id,value,onChange}) => {
  return (
    <>
      <label htmlFor={id}>{label}</label>
      <input type="text" defaultValue={value} onChange={e=>onChange(e.target.value)} />
    </>
  )
}
