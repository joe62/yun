import React from 'react'

const FormulaForm = () => {
  return (
    <div>FormulaForm</div>
  )
}

export default FormulaForm