import React, { useState } from 'react'
import {TextInput} from './components/textInput'
import { NumberInput } from './components/numberInput'

const App = () => {
  const [ingredients, setIngredients]= useState({})
  function handleChange(ingredient){
    setIngredients({
      ...ingredients,
      ingredient
    })
  }
  return (
    <div>caluloaf
      <TextInput value="80" onChange={value=>handleChange({"flour":value})} />
      <NumberInput />
      <pre><code>{JSON.stringify(ingredients,null,2)}</code></pre>
    </div>
  )
}

export default App