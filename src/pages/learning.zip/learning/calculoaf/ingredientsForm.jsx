import React from 'react'

const IngredientsForm = () => {
  return (
    <div>IngredientsForm</div>
  )
}

export default IngredientsForm