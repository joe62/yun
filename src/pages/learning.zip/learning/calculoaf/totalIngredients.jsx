import React from 'react'

const TotalIngredients = () => {
  return (
    <div>TotalIngredients</div>
  )
}

export default TotalIngredients