export const BreadCalcultor = {
  entryModeEnum: { WEIGHT: 0, PERCENTAGE: 1 },
  dirty: false,
  weight_type: "weight",
  decimals: 1,
  dairy_data: [
    {
      id: "dairy_type_skim_milk_0_1",
      preset: 0,
      protein: 3.5,
      fat: 0.1,
      carbs: 4.7,
      sugars: 4.7,
      ash: 0.7,
      salt: 0,
      hydration: 91,
    },
    {
      id: "dairy_type_skim_milk_0_3",
      preset: 1,
      protein: 3.5,
      fat: 0.3,
      carbs: 4.7,
      sugars: 4.7,
      ash: 0.7,
      salt: 0,
      hydration: 90.8,
    },
    {
      id: "dairy_type_skim_milk_0_5",
      preset: 2,
      protein: 3.5,
      fat: 0.5,
      carbs: 4.7,
      sugars: 4.7,
      ash: 0.7,
      salt: 0,
      hydration: 90.6,
    },
    {
      id: "dairy_type_low_fat_milk_1_0",
      preset: 3,
      protein: 3.5,
      fat: 1.0,
      carbs: 4.9,
      sugars: 4.9,
      ash: 0.7,
      salt: 0,
      hydration: 89.2,
    },
    {
      id: "dairy_type_whole_milk_3_5",
      preset: 4,
      protein: 3.5,
      fat: 3.5,
      carbs: 4.8,
      sugars: 4.8,
      ash: 0.7,
      salt: 0,
      hydration: 87.5,
    },
    {
      id: "dairy_type_cream_9",
      preset: 5,
      protein: 2.1,
      fat: 9,
      carbs: 3.2,
      sugars: 3.2,
      ash: 0.5,
      salt: 0,
      hydration: 85.2,
    },
    {
      id: "dairy_type_cream_12",
      preset: 6,
      protein: 2.1,
      fat: 12,
      carbs: 3.2,
      sugars: 3.2,
      ash: 0.5,
      salt: 0,
      hydration: 82.2,
    },
    {
      id: "dairy_type_cream_20",
      preset: 7,
      protein: 2.1,
      fat: 20,
      carbs: 3.2,
      sugars: 3.2,
      ash: 0.5,
      salt: 0,
      hydration: 74.2,
    },
    {
      id: "dairy_type_cream_33",
      preset: 8,
      protein: 2.1,
      fat: 33,
      carbs: 3.2,
      sugars: 3.2,
      ash: 0.5,
      salt: 0,
      hydration: 61.2,
    },
    {
      id: "dairy_type_cream_38",
      preset: 9,
      protein: 2.1,
      fat: 38,
      carbs: 3.2,
      sugars: 3.2,
      ash: 0.5,
      salt: 0,
      hydration: 56.2,
    },
    {
      id: "dairy_type_cream_50",
      preset: 10,
      protein: 2.1,
      fat: 50,
      carbs: 3.2,
      sugars: 3.2,
      ash: 0.5,
      salt: 0,
      hydration: 44.2,
    },
    {
      id: "dairy_type_yoghurt_3_6",
      preset: 11,
      protein: 3.8,
      fat: 3.6,
      carbs: 3.8,
      sugars: 3.8,
      ash: 0.8,
      salt: 0,
      hydration: 88,
    },
    {
      id: "dairy_type_yoghurt_0_1",
      preset: 12,
      protein: 3.8,
      fat: 0.1,
      carbs: 3.8,
      sugars: 3.8,
      ash: 0.8,
      salt: 0,
      hydration: 91.5,
    },
    {
      id: "dairy_type_butter_salted",
      preset: 13,
      protein: 0.5,
      fat: 81.4,
      carbs: 0.6,
      sugars: 0.6,
      ash: 1,
      salt: 1.2,
      hydration: 15.3,
    },
    {
      id: "dairy_type_butter_unsalted",
      preset: 14,
      protein: 0.5,
      fat: 81.4,
      carbs: 0.6,
      sugars: 0.6,
      ash: 1,
      salt: 0,
      hydration: 16.5,
    },
    {
      id: "dairy_type_low_fat_milk_2_0",
      preset: 15,
      protein: 3.5,
      fat: 2.0,
      carbs: 4.9,
      sugars: 4.9,
      ash: 0.7,
      salt: 0,
      hydration: 88.2,
    },
  ],
  egg_data: [
    {
      id: "egg_type_whole",
      preset: 0,
      protein: 13,
      fat: 11,
      carbs: 1.1,
      sugars: 1.1,
      ash: 1,
      salt: 0,
      hydration: 75,
    },
    {
      id: "egg_type_yolk",
      preset: 1,
      protein: 17,
      fat: 33,
      carbs: 3.6,
      sugars: 0.6,
      ash: 1,
      salt: 0,
      hydration: 49,
    },
    {
      id: "egg_type_white",
      preset: 2,
      protein: 11,
      fat: 0.2,
      carbs: 0.7,
      sugars: 0.7,
      ash: 0,
      salt: 0,
      hydration: 89,
    },
  ],
  sugar_data: [
    {
      id: "sugar_type_sugar",
      preset: 0,
      protein: 0,
      fat: 0,
      carbs: 100,
      sugars: 100,
      ash: 0,
      salt: 0,
      hydration: 0,
    },
    {
      id: "sugar_type_honey",
      preset: 1,
      protein: 0,
      fat: 0,
      carbs: 82,
      sugars: 82,
      ash: 0,
      salt: 0,
      hydration: 18,
    },
  ],
  misc_data: [],
  formula: {},
  stats: {},
  notes_right: true,
  decodeHTML: function (html) {
    let txt = document.createElement("textarea");
    txt.innerHTML = html;
    return txt.value;
  },
  getDoughSection: function () {
    let section = null;
    this.formula.sections.forEach((v, i) => {
      if (v.type === "dough") {
        section = v;
        return false;
      }
    });
    return section;
  },
  getPrefermentSection: function () {
    let section = null;
    this.formula.sections.forEach((v, i) => {
      if (v.type === "preferment") {
        section = v;
        return false;
      }
    });
    return section;
  },
  getDoughSections: function () {
    let sections = [];
    this.formula.sections.forEach((v, i) => {
      if (v.type !== "preferment") {
        sections.push(v);
      }
    });
    return sections;
  },
  getPrefermentSections: function () {
    let sections = [];
    this.formula.sections.forEach((v, i) => {
      if (v.type === "preferment") {
        sections.push(v);
      }
    });
    return sections;
  },
  toNumber: function (value) {
    if (typeof value === "number") {
      return value;
    }
    if (typeof value !== "string") {
      return value === 0 ? value : +value;
    }
    return NaN;
  },

  round: function (number) {
    number = this.toNumber(number);
    return (
      Math.round(number * Math.pow(10, this.decimals)) /
      Math.pow(10, this.decimals)
    );
  },
  round0: function (number) {
    number = this.toNumber(number);
    return Math.round(number)
  },
  round1: function (number) {
    number = this.toNumber(number);
    return Math.round(number*10)/10
  },
  round2: function (number) {
    number = this.toNumber(number);
    return Math.round(number*100)/100
  },
  hoursToFerment: function (proofTemp) {
    if (this.stats.inoculation === 0) return 0;
    let f = (proofTemp * 9) / 5 + 32;
    return this.round((
      Math.log(this.stats.inoculation / 100 / 0.894) *
      (-0.0000336713 * f ** 4 +
        0.0105207916 * f ** 3 -
        1.2495985607 * f ** 2 +
        67.0024722564 * f -
        1374.6540546564)
    ));
  },
  convertSectionType: function (type) {
    if (type.length === 1) {
      switch (type) {
        case "p":
          return "preferment";
        case "d":
          return "dough";
        case "s":
          return "soaker";
        case "m":
          return "misc";
        default:
          break;
      }
    } else {
      switch (type) {
        case "preferment":
          return "p";
        case "dough":
          return "d";
        case "soaker":
          return "s";
        case "misc":
          return "m";
        default:
          break;
      }
    }
  },
  convertIngredientType: function (type) {
    if (type.length === 1) {
      switch (type) {
        case "f":
          return "flour";
        case "d":
          return "fluid";
        case "t":
          return "salt";
        case "s":
          return "starter";
        case "e":
          return "extra";
        case "a":
          return "fat";
        case "u":
          return "sugar";
        case "y":
          return "yeast";
        case "g":
          return "egg";
        case "i":
          return "dairy";
        case "m":
          return "misc";
          default:
            break;
      }
    } else {
      switch (type) {
        case "flour":
          return "f";
        case "fluid":
          return "d";
        case "salt":
          return "t";
        case "starter":
          return "s";
        case "extra":
          return "e";
        case "sugar":
          return "u";
        case "fat":
          return "a";
        case "yeast":
          return "y";
        case "egg":
          return "g";
        case "dairy":
          return "i";
        case "misc":
          return "m";
          default:
            break;
      }
    }
  },
  generateVitals: function () {
    this.calculateStats();
    let result =
      '<!-- wp:advgb/table {"changed":true,"className":"foodgeek_bread_formula"} -->\n';
    result +=
      '<table class="wp-block-advgb-table advgb-table-frontend foodgeek_bread_formula"><tbody>';
    result +=
      "<tr><td>Total weight</td><td>" + this.stats.total + " grams</td></tr>";
    result +=
      "<tr><td>Pre-fermented flour</td><td>" +
      ((this.stats.prefermented_flour * 100) / this.stats.flour).toLocaleString(
        undefined,
        { maximumFractionDigits: 1 }
      ) +
      "%</td></tr>";
    result +=
      "<tr><td>Hydration</td><td>" +
      this.stats.hydration.toLocaleString(undefined, {
        maximumFractionDigits: 1,
      }) +
      "%</td></tr>";
    result +=
      "<tr><td>Yield</td><td>" +
      this.formula.quantity +
      " xxx</td></tr></tbody></table>\n";
    result += "<!-- /wp:advgb/table -->";
    return result;
  },
  generateURL: function () {
    let url = new URLSearchParams(window.location.search);
    url.delete("fbclid");
    url.delete("n");
    url.delete("a");
    url.delete("q");
    url.delete("nr");
    for (let i = 0; i < 10; i++) {
      url.delete("s" + i);
      url.delete("s" + i + "t");
      for (let j = 0; j < 100; j++) {
        url.delete("s" + i + "i" + j + "w");
        url.delete("s" + i + "i" + j + "t");
        url.delete("s" + i + "i" + j + "n");
        url.delete("s" + i + "i" + j + "h");
        url.delete("s" + i + "i" + j + "p");
        url.delete("s" + i + "i" + j + "r");
        url.delete("s" + i + "i" + j + "f");
        url.delete("s" + i + "i" + j + "c");
        url.delete("s" + i + "i" + j + "a");
        url.delete("s" + i + "i" + j + "s");
        url.delete("s" + i + "i" + j + "h");
      }
    }
    url.delete("u");
    url.delete("nt");
    url.set("n", encodeURI(this.formula.name));
    url.set("a", encodeURI(this.formula.author));
    url.set("q", encodeURI(this.formula.quantity));
    url.set("nr", encodeURI(this.notes_right ? 1 : 0));
    let that = this;
    this.formula.sections.forEach((v,i)=> {
      url.set("s" + i, encodeURI(v.name));
      url.set("s" + i + "t", that.convertSectionType(v.type));
      v.ingredients.forEach((o,j)=> {
        url.set("s" + i + "i" + j + "w", o.weight);
        url.set("s" + i + "i" + j + "t", that.convertIngredientType(o.type));
        url.set("s" + i + "i" + j + "n", encodeURI(o.name));
        if (o.type === "starter") {
          url.set("s" + i + "i" + j + "h", o.hydration);
        }
        if (o.type === "dairy" || o.type === "misc" || o.type === "sugar") {
          url.set("s" + i + "i" + j + "p", o.preset);
          if (o.preset === -1) {
            if (!isNaN(o.protein)) {
              url.set("s" + i + "i" + j + "r", o.protein);
            }
            if (!isNaN(o.fat)) {
              url.set("s" + i + "i" + j + "f", o.fat);
            }
            if (!isNaN(o.carbs)) {
              url.set("s" + i + "i" + j + "c", o.carbs);
            }
            if (!isNaN(o.sugars)) {
              url.set("s" + i + "i" + j + "u", o.sugars);
            }
            if (!isNaN(o.ash)) {
              url.set("s" + i + "i" + j + "a", o.ash);
            }
            if (!isNaN(o.salt)) {
              url.set("s" + i + "i" + j + "s", o.salt);
            }
            if (!isNaN(o.hydration)) {
              url.set("s" + i + "i" + j + "h", o.hydration);
            }
          }
        }
        if (o.type === "egg") {
          url.set("s" + i + "i" + j + "p", o.preset);
        }
      });
    });
    url.set("u", encodeURI(this.formula.url));
    url.set("nt", encodeURI(this.formula.notes));
    return (
      window.location.protocol +
      "//" +
      window.location.host +
      window.location.pathname +
      "?" +
      url.toString()
    );
  },
  generateIngredients: function () {
    let result = this.formula.name + "\n";
    this.formula.sections.forEach((v,i) => {
      result += v.name + "\n";
      v.ingredients.forEach((ingredient,j) => {
        result += ingredient.weight + "g " + ingredient.name + "\n";
      });
    });
    return result;
  },
  generateShortCode: function () {
    let that = this;
    let result =
      '<!-- wp:shortcode -->\n[foodgeek_bread_formula name="' +
      this.formula.name +
      '" author="' +
      this.formula.author +
      '"]';
      this.formula.sections.forEach((v,i)=> {
      result += '[foodgeek_bread_formula_section name="' + v.name + '"]';
      let flour = that.stats.flour;
      if (v.type === "preferment") {
        flour = 0;
        v.ingredients.forEach((o,j)=> {
          if (o.type === "flour") {
            flour += o.weight;
          }
        });
      }
      v.ingredients.forEach((o,j)=> {
        result +=
          '[foodgeek_bread_formula_ingredient weight="' +
          that.round(o.weight) +
          '" type="' +
          o.type +
          '" name="' +
          o.name +
          '" bakers_pct="' +
          o.bakers_pct +
          '"';
        if (o.type === "starter") {
          result += ' hydration="' + o.hydration + '"';
        }
        result += "]";
      });
      result += "[/foodgeek_bread_formula_section]";
    });
    result += "[/foodgeek_bread_formula]\n<!-- /wp:shortcode -->";
    return result;
  },
  calculateStats: function () {
    let flour = 0;
    let flour_starter = 0;
    let flour_preferment = 0;
    let flour_dough = 0;
    let fluid = 0;
    let fluid_starter = 0;
    let fluid_starter_dough = 0;
    let fluid_preferment = 0;
    let fluid_dough = 0;
    let none = 0;
    let salt = 0;
    let protein = 0;
    let carbs = 0;
    let ash = 0;
    let extra = 0;
    let fat = 0;
    let sugar = 0;
    let yeast = 0;
    let misc = 0;
    let preferment = 0;
    let prefermented_flour = 0;
    let preferments = 0;
    let sectionFlour = {};
    let sectionWeight = {};
    let that = this;
    this.formula.sections.forEach((v, i) => {
      if (v.type === "preferment") {
        preferments++;
      }
      if (typeof sectionFlour[i] === "undefined") {
        sectionFlour[i] = 0;
      }
      if (typeof sectionWeight[i] === "undefined") {
        sectionWeight[i] = 0;
      }
      v.ingredients.forEach((o, j) => {
        sectionWeight[i] += this.round(o.weight);
        if (v.type === "preferment") {
          preferment += o.weight;
        }
        switch (o.type) {
          case "flour":
            flour += o.weight;
            if (v.type === "preferment") {
              flour_preferment += o.weight;
              prefermented_flour += o.weight;
            }
            if (v.type === "dough") {
              flour_dough += o.weight;
            }
            sectionFlour[i] += o.weight;
            break;
          case "starter":
            let a = o.weight / (1 + o.hydration / 100);
            flour_starter += a;
            flour += a;
            prefermented_flour += a;
            a = o.weight * (o.hydration / 100 / (1 + o.hydration / 100));
            fluid_starter += a;
            fluid += a;
            if (v.type === "dough") {
              fluid_starter_dough += a;
            }
            break;
          case "fluid":
            if (v.type !== "soaker") {
              fluid += o.weight;
              if (v.type === "preferment") {
                fluid_preferment += o.weight;
              }
              if (v.type === "dough") {
                fluid_dough += o.weight;
              }
            }
            break;
          case "dairy":
          case "egg":
          case "sugar":
          case "misc":
            let f = o.weight * (o.hydration / 100);
            fluid += f;
            let m = 0;
            if (typeof o.fat === "number" && !isNaN(o.fat)) {
              let w = o.weight * (o.fat / 100);
              fat += w;
              m += w;
            }
            if (typeof o.protein === "number" && !isNaN(o.protein)) {
              let w = o.weight * (o.protein / 100);
              protein += w;
              m += w;
            }
            if (typeof o.carbs === "number" && !isNaN(o.carbs)) {
              let w = o.weight * (o.carbs / 100);
              carbs += w;
              m += w;
            }
            if (typeof o.sugars === "number" && !isNaN(o.sugars)) {
              let w = o.weight * (o.sugars / 100);
              sugar += w;
              m += w;
            }
            if (typeof o.ash === "number" && !isNaN(o.ash)) {
              let w = o.weight * (o.ash / 100);
              ash += w;
              m += w;
            }
            if (typeof o.salt === "number" && !isNaN(o.salt)) {
              let w = o.weight * (o.salt / 100);
              salt += w;
              m += w;
            }
            if (v.type === "preferment") {
              fluid_preferment += f;
            }
            if (v.type === "dough") {
              fluid_dough += f;
            }
            misc += o.weight * ((100 - o.hydration) / 100) - m;
            break;
          case "salt":
            salt += o.weight;
            break;
          case "yeast":
            yeast += o.weight;
            break;
          case "fat":
            fat += o.weight;
            break;
          case "extra":
            extra += o.weight;
            break;
          case "none":
            none += o.weight;
            break;
          default:
            break;
        }
      });
    });
    this.formula.sections.forEach((v, i) => {
      v.ingredients.forEach((o, j) => {
        if (v.type === "preferment") {
          o.bakers_pct = that.round((o.weight * 100) / sectionFlour[i]);
        } else {
          o.bakers_pct = 0;
          if (flour_dough > 0) {
            o.bakers_pct = that.round((o.weight * 100) / flour_dough);
          }
        }
      });
      this.stats.flour = this.round(flour);
      this.stats.flour_starter = this.round(flour_starter);
      this.stats.fluid = this.round(fluid);
      this.stats.fluid_starter = this.round(fluid_starter);
      this.stats.fluid_starter_dough = this.round(fluid_starter_dough);
      this.stats.salt = this.round2(salt);
      this.stats.yeast = this.round2(yeast);
      this.stats.fat = this.round2(fat);
      this.stats.sugar = this.round(sugar);
      this.stats.extra = this.round(extra);
      this.stats.flour_preferment = this.round(flour_preferment);
      this.stats.fluid_preferment = this.round(fluid_preferment);
      this.stats.flour_dough = this.round(flour_dough);
      this.stats.fluid_dough = this.round(fluid_dough);
      this.stats.prefermented_flour =this.round( prefermented_flour);
      this.stats.total =this.round(
        flour +
        fluid +
        salt +
        extra +
        fat +
        sugar +
        yeast +
        protein +
        carbs +
        ash +
        misc +
        none);
    });
    this.stats.preferment_pct = (preferment / flour_dough) * 100;
    this.stats.inoculation = this.calculateInoculationPct();
    this.stats.preferments = preferments;
    this.stats.hydration = 0;
    this.stats.salt_pct = 0;
    this.stats.section_weight = sectionWeight;
    this.stats.section_flour = sectionFlour;
    if (flour > 0) {
      this.stats.hydration = this.round2((fluid * 100) / flour);
      this.stats.salt_pct = this.round2((salt * 100) / flour);
    }
    this.stats.fat_pct = 0;
    if (fat > 0) {
      this.stats.fat_pct = this.round2((fat * 100) / flour);
    }
    this.stats.sugar_pct = 0;
    if (sugar > 0) {
      this.stats.sugar_pct = this.round2((sugar * 100) / flour);
    }
    let q = this.formula.quantity;
    this.stats.onebread = {};
    this.stats.onebread.flour = this.round2(flour / q);
    this.stats.onebread.flour_starter = this.round2(flour_starter / q);
    this.stats.onebread.fluid = this.round2(fluid / q);
    this.stats.onebread.fluid_starter = this.round2(fluid_starter / q);
    this.stats.onebread.fluid_starter_dough = this.round2(fluid_starter_dough / q);
    this.stats.onebread.salt = this.round2(salt / q);
    this.stats.onebread.yeast = this.round2(yeast / q);
    this.stats.onebread.fat = this.round2(fat / q);
    this.stats.onebread.sugar = this.round2(sugar / q);
    this.stats.onebread.extra = this.round2(extra / q);
    this.stats.onebread.flour_preferment = this.round2(flour_preferment / q);
    this.stats.onebread.fluid_preferment = this.round2(fluid_preferment / q);
    this.stats.onebread.flour_dough = this.round2(flour_dough / q);
    this.stats.onebread.fluid_dough = this.round2(fluid_dough / q);
    this.stats.onebread.prefermented_flour = this.round2(prefermented_flour / q);
    this.stats.onebread.total = this.round2(this.stats.total / q);
    this.stats.onebread.preferment_pct = this.round2(this.stats.preferment_pct / q);
    this.stats.fermentation = {};
    this.stats.fermentation.temp5 = this.hoursToFerment(5);
    this.stats.fermentation.temp10 = this.hoursToFerment(10);
    this.stats.fermentation.temp18 = this.hoursToFerment(18);
    this.stats.fermentation.temp21 = this.hoursToFerment(21);
    this.stats.fermentation.temp30 = this.hoursToFerment(30);
  },
  calculateInoculationPct: function () {
    let prefermentSections = this.getPrefermentSections();
    let doughSections = this.getDoughSections();
    let weight = 0;
    let flour = 0;
    prefermentSections.forEach((prefermentSection, i) => {
      let ingredients = prefermentSection.ingredients;
      for (let i = 0; i < ingredients.length; i++) {
        weight += ingredients[i].weight;
      }
    });
    doughSections.forEach((doughSection, i) => {
      let ingredients = doughSection.ingredients;
      for (let i = 0; i < ingredients.length; i++) {
        if (ingredients[i].type === "starter") {
          weight = ingredients[i].weight;
          continue;
        }
        if (ingredients[i].type === "flour") {
          flour += ingredients[i].weight;
        }
      }
    });
    if (flour === 0) {
      return 0;
    }
    return this.round((weight * 100) / flour);
  },
  calculateFromTotalWeight: function (totalWeight) {
    this.calculateStats();
    let that = this;
    this.formula.sections.forEach((v, i) => {
      v.ingredients.forEach((o, j) => {
        o.weight = that.round((o.weight / that.stats.total) * totalWeight);
      });
    });

    this.dirty = true;
    this.renderEditor();
  },
  calculateNewHydration: function (newHydration) {
    let that = this;
    let foundFluid = false;

    this.getDoughSection().ingredients.forEach((v,j) => {
      if (
        v.type === "fluid" ||
        v.type === "dairy" ||
        v.type === "egg" ||
        v.type === "misc"
      ) {
        foundFluid = true;
        return false;
      }
    });

    if (!foundFluid) {
      this.getDoughSection().ingredients.push({
        type: "fluid",
        weight: 0,
        name: "fgbc.water",
      });
    }
    this.getDoughSection().ingredients.forEach((v,j)=>{
      if (
        v.type === "fluid" ||
        v.type === "dairy" ||
        v.type === "egg" ||
        v.type === "misc"
      ) {
        v.weight = that.round(
          (that.stats.flour * newHydration) / 100 -
            that.stats.fluid_preferment -
            that.stats.fluid_starter -
            (that.stats.fluid_dough - v.weight)
        );
        return false;
      }
    });
    this.dirty = true;
    this.renderEditor();
  },
  calculateNewInoculationPct: function (value, rescale) {
    value = parseFloat(value);
    let prefermentSections = this.getPrefermentSections();
    let doughSections = this.getDoughSections();
    let that = this;
    if (prefermentSections.length > 0) {
      let oldPrefermentPct = this.calculateInoculationPct();
      prefermentSections.forEach((prefermentSection)=> {
        let ingredients = prefermentSection.ingredients;
        for (let i = 0; i < ingredients.length; i++) {
          ingredients[i].weight *= value / oldPrefermentPct;
        }
      });
    } else {
      doughSections.forEach((doughSection) =>{
        let ingredients = doughSection.ingredients;
        for (let i = 0; i < ingredients.length; i++) {
          if (ingredients[i].type === "starter") {
            ingredients[i].weight =
              (value * (that.stats.flour - that.stats.flour_starter)) / 100;
            break;
          }
        }
      });
    }
    let oldTotalWeight = this.stats.total;
    let oldHydration = this.stats.hydration;
    this.calculateStats();
    this.calculateNewHydration(oldHydration);
    if (rescale) {
      this.calculateFromTotalWeight(oldTotalWeight);
    }
    this.dirty = true;
    this.renderEditor();
  },
  recalculateFromYeast: function (newStarter) {
    let totalWeight = Math.round(this.stats.total);
    let ingredients = this.getDoughSection().ingredients;
    let newStarterWeight =
      ((this.stats.flour - (this.stats.flour * (newStarter / 2)) / 100) *
        newStarter) /
      100;
    let starterWeight20 = (this.stats.flour * newStarter) / 100;
    let deductFlour = starterWeight20 / 2;
    let deductFluid = starterWeight20 / 2;
    let deleteIngredients = [];
    for (let i = 0; i < ingredients.length; i++) {
      if (deductFlour > 0) {
        if (ingredients[i].type === "flour") {
          let weight = ingredients[i].weight;
          ingredients[i].weight -= deductFlour;
          if (ingredients[i].weight < 0) {
            deductFlour -= weight;
            deleteIngredients.push(i);
          } else {
            deductFlour = 0;
          }
        }
      }
      if (deductFluid > 0) {
        if (ingredients[i].type === "fluid") {
          let weight = ingredients[i].weight;
          ingredients[i].weight -= deductFluid;
          if (ingredients[i].weight < 0) {
            deductFluid -= weight;
            deleteIngredients.push(i);
          } else {
            deductFluid = 0;
          }
        }
      }
      if (ingredients[i].type === "yeast") {
        deleteIngredients.push(i);
      }
    }
    for (let i = deleteIngredients.length - 1; i >= 0; i--) {
      let index = deleteIngredients[i];
      ingredients.splice(index, 1);
    }
    ingredients.push({
      type: "starter",
      weight: newStarterWeight,
      hydration: 100,
      name: 'fgbc.starter',
    });
    this.calculateFromTotalWeight(totalWeight);
    this.dirty = true;
    this.renderEditor();
  },
  copyURLToClipboard: function () {
    let url = this.generateURL();
    navigator.clipboard.writeText(url).then(() => {
      alert("复制链接！");
    });

  },
  parseURL: function () {
    var that = this;
    var url = new URLSearchParams(window.location.search);
    console.log(url)
    var name = url.get("n");
    if (!name) {
      return;
    }
    var scaleTo = parseInt(url.get("scale_to"));
    this.notes_right = parseInt(decodeURI(url.get("nr"))) == 0 ? false : true;
    this.formula.name = decodeURI(name);
    this.formula.author = decodeURI(url.get("a"));
    this.formula.url = decodeURI(url.get("u") || "");
    this.formula.quantity = parseInt(decodeURI(url.get("q")));
    if (
      !this.formula.url.startsWith("https://foodgeek.dk") &&
      !this.formula.url.startsWith("https://fdgk.") &&
      !this.formula.url.startsWith("https://fgbc.dk")
    ) {
      this.formula.url = "".url = "";
    }
    this.formula.notes = decodeURI(url.get("nt") || "");
    this.formula.sections = [];
    for (var i = 0; i < 10; i++) {
      var section = {};
      var name = url.get("s" + i);
      if (!name) {
        break;
      }
      section.name = decodeURI(name);
      section.type = this.convertSectionType(url.get("s" + i + "t"));
      section.ingredients = [];
      for (var j = 0; j < 50; j++) {
        var ingredient = {};
        var weight = url.get("s" + i + "i" + j + "w");
        if (!weight) {
          break;
        }
        ingredient.weight = parseFloat(weight);
        ingredient.type = this.convertIngredientType(
          url.get("s" + i + "i" + j + "t")
        );
        ingredient.name = decodeURI(url.get("s" + i + "i" + j + "n"));
        if (ingredient.type == "starter") {
          ingredient.hydration = parseInt(url.get("s" + i + "i" + j + "h"));
        }
        if (ingredient.type == "dairy" || ingredient.type == "misc") {
          var preset = parseInt(url.get("s" + i + "i" + j + "p"));
          ingredient.preset = preset;
          if (ingredient.preset >= 0) {
            var dairy = that.dairy_data[preset];
            ingredient.protein = dairy.protein;
            ingredient.fat = dairy.fat;
            ingredient.carbs = dairy.carbs;
            ingredient.sugars = dairy.sugars;
            ingredient.ash = dairy.ash;
            ingredient.salt = dairy.salt;
            ingredient.hydration = dairy.hydration;
          } else {
            ingredient.protein = parseFloat(url.get("s" + i + "i" + j + "r"));
            ingredient.fat = parseFloat(url.get("s" + i + "i" + j + "f"));
            ingredient.carbs = parseFloat(url.get("s" + i + "i" + j + "c"));
            ingredient.sugars = parseFloat(url.get("s" + i + "i" + j + "u"));
            ingredient.ash = parseFloat(url.get("s" + i + "i" + j + "a"));
            ingredient.salt = parseFloat(url.get("s" + i + "i" + j + "s"));
            ingredient.hydration = parseFloat(url.get("s" + i + "i" + j + "h"));
          }
        }
        if (ingredient.type == "egg") {
          var preset = parseInt(url.get("s" + i + "i" + j + "p"));
          ingredient.preset = preset;
          var egg = that.egg_data[preset];
          ingredient.protein = egg.protein;
          ingredient.fat = egg.fat;
          ingredient.carbs = egg.carbs;
          ingredient.ash = egg.ash;
          ingredient.hydration = egg.hydration;
        }
        if (ingredient.type == "sugar") {
          var preset = parseInt(url.get("s" + i + "i" + j + "p"));
          if (isNaN(preset)) {
            preset = 0;
          }
          ingredient.preset = preset;
          if (ingredient.preset >= 0) {
            ingredient.preset = preset;
            var sugar = that.sugar_data[preset];
            ingredient.carbs = sugar.carbs;
            ingredient.sugars = sugar.sugars;
            ingredient.hydration = sugar.hydration;
          } else {
            ingredient.carbs = parseFloat(url.get("s" + i + "i" + j + "c"));
            ingredient.sugars = parseFloat(url.get("s" + i + "i" + j + "u"));
            ingredient.hydration = parseFloat(url.get("s" + i + "i" + j + "h"));
          }
        }
        section.ingredients.push(ingredient);
      }
      this.formula.sections.push(section);
    }
    if (scaleTo > 0) {
      this.calculateFromTotalWeight(scaleTo);
    }
    this.calculateStats();
  },
  renderEditor: function () {
    this.calculateStats();
  },
};
