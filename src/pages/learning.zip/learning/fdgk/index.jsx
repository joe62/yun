import React, { useState } from "react";
import Modal from "../../../components/InputDialog/modal";
import CountryBread from "../../../../data/recipe/乡村面包.json";
import {BreadCalcultor} from './breadCalc'

const modifies = [
  { name: `total-weight`, title: `面团重量(g)`, type: "number" },
  { name: `dough-hydration`, title: `面团含水量(%)`, type: "number" },
  { name: `inoculation`, title: `酵种量(%)`, type: "number" },
  { name: `yeast2starter`, title: `干酵母转换为酵种(%)`, type: "number" },
  { name: `import-recipe`, title: `导入配方`, type: "file" },
];

const FoodgeekBakingBreadCalulator = () => {
  const [showModal, setShowModal] = useState(false);
  const [modefyRecipe, setModefyRecipe] = useState();
  const [recipe, setRecipe] = useState(CountryBread);

  const handleOnchanged = ({ target: { type,name, value,files } }) => {
    if(type!=='file')
    setModefyRecipe({ ...modefyRecipe, value });
    else 
    setModefyRecipe({ ...modefyRecipe, value:files[0] });

  };
  const handleDialog = (state) => {
    if (!state) return;
    switch (modefyRecipe.name) {
      case "total-weight":
        BreadCalcultor.calculateFromTotalWeight(modefyRecipe.value);
        break;
      case "dough-hydration":
        BreadCalcultor.calculateNewHydration(modefyRecipe.value);
        break;
      case "inoculation":
        BreadCalcultor.calculateNewInoculationPct(modefyRecipe.value);
        break;
      case "yeast2starter":
        BreadCalcultor.recalculateFromYeast(modefyRecipe.value);
        break;
      case "import-recipe":
        const fileReader = new FileReader();
        fileReader.readAsText(modefyRecipe.value, "UTF-8");
        fileReader.onload = e=>{
          const data = JSON.parse(e.target?.result)
          setRecipe(data)    
          
        }
        break;
      
      default:
        break;
    }
  };
  
          BreadCalcultor.formula = recipe;
          BreadCalcultor.calculateStats();
 const getValue=(name)=>{
  let value = 0;
  switch (name) {
    case "total-weight":
      value = BreadCalcultor.stats.total
      break;
    case "dough-hydration":
      value = BreadCalcultor.stats.hydration
      break;
    case "inoculation":
      value = BreadCalcultor.stats.inoculation
      break;
    case "yeast2starter":
        value = BreadCalcultor.stats.yeast
        console.log(value)
        break;
    default:
      value=null
      break;
  }
  return value
 }
//  console.log(BreadCalcultor.generateURL())
//  console.log(BreadCalcultor.generateShortCode())
//  console.log(BreadCalcultor.generateVitals())
//  console.log(BreadCalcultor.generateIngredients())
// BreadCalcultor.copyURLToClipboard()
  return (
    <>
      <div className="flex items-center justify-center mt-2">
        {modifies.map(({ name, title, type }, index) => (
          <>
            <button
              className={`mx-2 px-4 py-2 text-purple-${getValue(name)===0?'400':'100'} bg-purple-600 rounded-md`}
              type="button"
              onClick={() => {
                setShowModal(true);
                let value=getValue(name);
                console.log(value)
                setModefyRecipe({ name, title, type, value});
              }}
              disabled={getValue(name)===0}
            >
              {title}
            </button>
          </>
        ))}
         <button
              className={`mx-2 px-4 py-2 text-purple-100 bg-purple-600 rounded-md`}
              type="button"
              onClick={() => {
                BreadCalcultor.copyURLToClipboard()
                BreadCalcultor.parseURL()
              }}
             
            >
             复制配方链接到剪切板
            </button>
        {showModal && (
          <>
            <Modal
              setOpenModal={setShowModal}
              callback={handleDialog}
              title={modefyRecipe.title}
            >
               <input
                onChange={handleOnchanged}
                className="w-full mt-2 p-2.5 flex-1 text-white bg-sky-600 rounded-md"
                type={modefyRecipe.type}
                name={modefyRecipe.name}
                id={modefyRecipe.name}
                value={modefyRecipe.type==='file'?null:modefyRecipe.value}
                
              />
            </Modal>
          </>
        )}
      </div>
      {recipe && (
        <pre>
          <code>{JSON.stringify(BreadCalcultor.stats, null, 2)}</code>
          <br />
          <code>{JSON.stringify(BreadCalcultor.formula, null, 2)}</code>
        </pre>
      )}
    </>
  );
};

export default FoodgeekBakingBreadCalulator;
