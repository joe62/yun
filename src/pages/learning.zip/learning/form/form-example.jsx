import React,{useReducer, useState} from 'react'

const formReducer = (state,event)=>{
  if(event.reset)
{
  return {
    apple:'',
    count:0,
    name:'',
    'gift-wrap': false
  }
}  return {
    ...state,
    [event.name]:event.value
  }
}

const Form = () => {
  const [formData, setFormData] = useReducer(formReducer,{count:100,name:'zyf',apple:'jonathan','gift-wrap':true})
  const [submitting,setSubmmitting]=useState(false)

  const handleSubmit = event =>{
    event.preventDefault()
    setSubmmitting(true)

    setTimeout(()=>{
      setSubmmitting(false)
      setFormData({
        reset:true
      })
    },3000)
  }

  const handleChange = event =>{
    const isCheckbox = event.target.type === 'checkbox'
    setFormData({
      name:event.target.name,
      value: isCheckbox ? event.target.checked:  event.target.value
    })
  }
  return (
    <>
    <div className=' py-1 px-5 ' >
      <h1>How About Them Apples</h1>
      <a href="https://www.digitalocean.com/community/tutorials/how-to-build-forms-in-react">url</a>
      {submitting && 
      <div>
        You are subiiting the following:
        <ul className='mx-0 my-5 px-10'>
          {Object.entries(formData).map(([name,value])=>(
            <li key={name}><strong>{name}</strong>:{value.toString()}</li>
          ))}</ul>  
      </div>}
      <form onSubmit={handleSubmit} >
        <fieldset className=' mx-0 my-5 p-5 border border-gray-800'>
          <label>
            <p>Name</p>
            <input className='border border-gray-600'  name="name" onChange={handleChange} value={formData.name||''} />
          </label>
        </fieldset>
        <fieldset className=' mx-0 my-5 p-5 border border-gray-800' >
          <label >
            <p>Apples</p>
            <select className='my-5 border border-gray-800' name="appple"  onChange={handleChange} value={formData.apple || ''}>
              <option value="">--Please choose an option--</option>
              <option value="fuji">Fuji</option>
              <option value="jonathan">Jonathan</option>
              <option value="honey-crisp">Honey Crisp</option>
            </select>
          </label>
          <label>
            <p>Count</p>
            <input className='mx-0 my-5 p-2 border border-gray-600' type="number" name="count" onChange={handleChange} value={formData.count || ''} />
          </label>
          <label >
            <p>Gift Wrap</p>
            <input checked={formData.apple !='fuji'} type="checkbox" name='gift-wrap' onChange={handleChange}  />
          </label>
        </fieldset>
        <button className=' px-5 py-1 border border-gray-700' type="submit">Submit</button>
      </form>
    </div>
    </>
  )
}

export default Form