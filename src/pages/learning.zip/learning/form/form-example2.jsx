import React from "react";

const App = () => {
  return (
    <>
      <h1 className="mt-2 mb-3 text-3xl text-blue-900 font-bold text-center">Trip Destination Form</h1>
      <form className="max-w-md mx-auto">
        <div className="mb-3">
          <label className="block mb-1" for="clientName">Client Name:</label>
          <input className="w-full px-3 py-2 border border-gray-400 rounded" type="text" id="clientName" name="clientName" required />
        </div>
        <div className="mb-3">
          <label className="block mb-1" for="TripDays">Days of Trip:</label>
          <input className="w-full px-3 py-2 border border-gray-400 rounded" type="number" id="TripDays" name="TripDays" required />
        </div>

        <div className="mb-3">
          <label className="block mb-1"  for="DesiredDestination">Desired Trip Destination:</label>
          <select className="w-full px-3 py-2 border border-gray-400 rounded" id="DesiredDestination" name="DesiredDestination">
            <option value="">--Select Country--</option>
            <option value="maldives">Maldives</option>
            <option value="canada">Canada</option>
            <option value="mexico">Mexico</option>
            <option value="japan">Japan</option>
            <option value="usa">USA</option>
            <option value="italy">Italy</option>
            <option value="france">France</option>
          </select>
        </div>

        <div className="mb-3">
          <label className="block mb-1" for="startDate">Start Date:</label>
          <input className="w-full px-3 py-2 border border-gray-400 rounded" type="date" id="startDate" name="startDate" required />
        </div>

        <div className="mb-3">
          <label className="block mb-1"  for="endDate">End Date:</label>
          <input className="w-full px-3 py-2 border border-gray-400 rounded" type="date" id="endDate" name="endDate" required />
        </div>

        <div className="mb-3">
          <label className="block mb-1" >Trip Type:</label>
          <div className="flex justify-items-center">
            <input
              className="mr-2"
              type="radio"
              id="business"
              name="tripType"
              value="business"
              required
            />
            <label className="mr-4" for="business">Business</label>

            <input
              className="mr-2"
              type="radio"
              id="solo"
              name="tripType"
              value="solo"
              required
            />
            <label className="mr-4" for="solo">Solo</label>

            <input
            className="mr-2"
              type="radio"
              id="family"
              name="tripType"
              value="family"
              required
            />
            <label className="mr-4" for="family">Family</label>
          </div>
        </div>

        <div className="mb-2">
          <label className="block mt-4 text-gray-700 font-bold" for="tripexpectations">Trip Expectations:</label>
          <textarea
            id="tripexpectations"
            name="tripexpectations"
            rows="2"
            className="mt-1 bg-gray-200 block w-full rounded-md border-gray-700 shadow-sm"
          ></textarea>
        </div>

        <button type="submit" className="mt-1 py-1 px-6 font-semibold rounded-lg text-white bg-indigo-500">Submit</button>
      </form>
    </>
  );
};

export default App;
