import React from "react";

const PlaceContentCenter = () => {
  return (
    <>
      <div className="text-center max-w-2xl">
        <div>
          <p>
            <b>Tailwind CSS Place Content Class</b>
          </p>
          <div
            className="grid grid-cols-3 gap-2 place-content-center bg-teal-200 
      border-spacing-2 border-solid border-4 border-gray-900"
          >
            <div className=" bg-teal-900 w-3/4 h-12">One</div>
            <div className=" bg-teal-800 w-3/4 h-12">Two</div>
            <div className=" bg-teal-700 w-3/4 h-12">Three</div>
            <div className=" bg-teal-600 w-3/4 h-12">Four</div>
            <div className=" bg-teal-500 w-3/4 h-12">Five</div>
            <div className=" bg-teal-400 w-3/4 h-12">Siz</div>
          </div>
        </div>
        <div>
          <p>
            <b>Tailwind CSS Place Content Class</b>
          </p>
          <div class="grid grid-cols-3 gap-2 place-content-start bg-teal-200 border-solid border-4 border-green-900">
            <div class="bg-teal-900 w-3/4 h-12">One</div>
            <div class="bg-teal-800 w-3/4 h-12">Two</div>
            <div class="bg-teal-700 w-3/4 h-12 ">Three</div>
            <div class="bg-teal-600 w-3/4 h-12">Four</div>
            <div class="bg-teal-500 w-3/4 h-12">Five</div>
            <div class="bg-teal-400 w-3/4 h-12">Six</div>
          </div>
        </div>
        <div>
          <p>
            <b>Tailwind CSS Place Content Class</b>
          </p>
          <div class="grid grid-cols-3 gap-2 place-content-end bg-teal-200 border-solid border-4 border-green-900">
            <div class="bg-teal-900 w-3/4 h-12">One</div>
            <div class="bg-teal-800 w-3/4 h-12">Two</div>
            <div class="bg-teal-700 w-3/4 h-12 ">Three</div>
            <div class="bg-teal-600 w-3/4 h-12">Four</div>
            <div class="bg-teal-500 w-3/4 h-12">Five</div>
            <div class="bg-teal-400 w-3/4 h-12">Six</div>
          </div>
        </div>
        <div>
          <p>
            <b>Tailwind CSS Place Content Class</b>
          </p>
          <div class="grid grid-cols-3 gap-2 place-content-between bg-teal-200 border-solid border-4 border-green-900">
            <div class="bg-teal-900 w-3/4 h-12">One</div>
            <div class="bg-teal-800 w-3/4 h-12">Two</div>
            <div class="bg-teal-700 w-3/4 h-12 ">Three</div>
            <div class="bg-teal-600 w-3/4 h-12">Four</div>
            <div class="bg-teal-500 w-3/4 h-12">Five</div>
            <div class="bg-teal-400 w-3/4 h-12">Six</div>
          </div>
        </div>
        <div>
          <p>
            <b>Tailwind CSS Place Content Class</b>
          </p>
          <div class="grid grid-cols-3 gap-2 place-content-around bg-teal-200 border-solid border-4 border-green-900">
            <div class="bg-teal-900 w-3/4 h-12">One</div>
            <div class="bg-teal-800 w-3/4 h-12">Two</div>
            <div class="bg-teal-700 w-3/4 h-12 ">Three</div>
            <div class="bg-teal-600 w-3/4 h-12">Four</div>
            <div class="bg-teal-500 w-3/4 h-12">Five</div>
            <div class="bg-teal-400 w-3/4 h-12">Six</div>
          </div>
        </div>
        <div class="flex space-x-8 m-10 h-20 w-max">

<div class="bg-teal-500 w-20 p-5">1</div>
<div class="bg-teal-500 w-20 p-5">2</div>
<div class="bg-teal-500 w-20 p-5">3</div>
<div class="bg-teal-500 w-20 p-5">4</div>
<div class="bg-teal-500 w-20 p-5">5</div>
<div class="bg-teal-500 w-20 p-5">6</div>

</div>
      </div>
    </>
  );
};

export default PlaceContentCenter;
