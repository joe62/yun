import React from "react";
import './style.css'
const PlaceContentCenter = () => {
  return (
    <>
   <div className="box">
    <p>外部样式表在一个单独的扩展名为 .css 的文件中包含 CSS。这是将 CSS 应用到文档中最常见和最有用的方法。你可以将一个 CSS 文件链接到多个网页上，用同一个 CSS 样式表为所有网页确定样式。在 CSS 入门中，我们将一个外部样式表链接到我们的网页上。</p>
   </div>
      
    </>
  );
};

export default PlaceContentCenter;
