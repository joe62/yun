import { Link } from 'gatsby'
import React from 'react'

const links = [
  {url:"./tailwind-components",name:"Tailwind 组件示例",des:"Tailwind 组件示例"},
    {url:"./navbar1",name:"导航1",des:"abc"},
    {url:"./navbar2",name:"导航2",des:"abc1"},
    {url:"./navbar3",name:"导航3",des:"abc2"},
    {url:"./sidebar",name:"Sidebar",des:"Responsive sidebar with tailwind"},
    {url:"./bread",name:"Bread Calc",des:"Sourdough Bread Calculator by dropout1692"},
    {url:"./bread-calc/sourCalc",name:"Sourdough Bread Calc",des:"Sourdough Bread Calculator by Joe"},
    {url:"./bread-calc/enrichedCalc",name:"Enriched Bread Calc",des:"Enriched Bread Calculator by Joe"},
    {url:"./bread-calc/bread-calculator",name:"Bread Calculator",des:"Enriched Bread Calculator by Joe"},
    {url:"./calculoaf",name:"Calc loaf",des:"calculator loaf"},

]

const App = () => {
  return (
    <div>
        <h1>Tailwind示例</h1>
        <ul>
            {links.map(({url,name,des},index)=>
            <li key={index}><Link to={url} title={des}>{name}</Link></li>
            )}
        </ul>
        
    </div>
  )
}

export default App