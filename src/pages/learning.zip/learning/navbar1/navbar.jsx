import React from 'react'

const links = [{url:"#",name:"Home"},{url:"#",name:"Featrues"},{url:"#",name:"Pricing"},{url:"#",name:"Contact"}]

const A = ({url,children}) => <a
className='block md:inline-block px-3 py-2 rounded-md hover:text-white hover:bg-gray-700 focus:outline-none focus:text-white focus:bg-gray-700'
href={url}>{children}</a>

const Navbar =() =>{
  return (
    <div className=' px-2 py-3 space-y-3 font-medium text-slate-700'>
        {links.map(({url,name},index)=><A href={url} key={index} >{name}</A>)}
    </div>
  )
}

export default Navbar