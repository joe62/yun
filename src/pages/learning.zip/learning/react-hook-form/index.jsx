import React,{useState} from 'react'
import { useForm } from 'react-hook-form'

const Input = ({label,register,required})=>(
  <>
  <label className= ' leading-8 text-left block mt-3 text-white font-extralight'>{label}</label>
  <input {...register(label,{required})} className='block box-border w-full rounded border border-white py-3 px-4 mb-3 text-gray-800' />
  </>
)


const Select = React.forwardRef(({ onChange, name, label }, ref) => (
  <>
    <label>{label}</label>
    <select name={name} ref={ref} onChange={onChange}>
      <option value="20">20</option>
      <option value="30">30</option>
    </select>
  </>
));

const Form = () => {
  const {register,handleSubmit}=useForm()
  const [data, setData] = useState("")
  return (
    <div className=' font-mono text-center bg-darkBlue text-white pt-0 pb-5'>
<form className=' max-w-3xl mt-0 mx-auto text-black' onSubmit={handleSubmit((data)=>setData(JSON.stringify(data)))}>
       <h1 className=' mt-20 text-white text-2xl pb-0'>React Hook Form</h1>
       <p>Performant, flexible and extensible forms with easy-to-use validation.</p>
      <Input label={'First Name'} register={register}/>
      <Select label="Age" {...register("Age")} />
      <select {...register("category",{required:true})} className='font-sans block box-border w-full rounded py-[10px] px-[20px] border border-white mb-4 text-sm'>
        <option value="">Select...</option>
        <option value="A">Option A</option>
        <option value="B">Option B</option>
      </select>
      <textarea {...register("aboutYou")} placeholder='About me' className='font-sans block box-border w-full rounded py-[10px] px-[20px] border border-white mb-4 text-sm'/>
      <p className='text-white'>{data}</p>
      <input className=' relative bg-pink-500 text-white uppercase border-none w-full font-semibold mt-5 p-5 text-base block appearance-none rounded tracking-widest duration-300  transition-all hover:bg-pink-800 ' type='submit'/>
      
    </form>
    </div>
    
  )
}

export default Form