# React Sidebar tainwind Darkmode
> Responsive sidebar built with React and Tailwind. Support for dar mode,react-router and Mobile. Feel free to contribue
> [demo](https://react-tailwind-dark-sidebar.netlify.app/) [source](https://github.com/idrsdev/react-sidebar-tailwind-darkmode)

## 配置

```js
//tailwind.config.js
module.exports = {
    content: ['./src/**/*.{js,jsx,ts,tsx}'],

    // enable dark mode via class strategy
    darkMode: 'class',

    theme: {
        extend: {
            colors: {
                black: '#09090c',
                darkGray: '#121212',
                
                brightRed: 'hsl(12, 88%, 59%)',
                brightRedLight: 'hsl(12, 88%, 69%)',
                brightRedSupLight: 'hsl(12, 88%, 95%)',

                darkBlue: 'hsl(228, 39%, 23%)',
                darkGrayishBlue: 'hsl(227, 12%, 61%)',
                veryDarkBlue: 'hsl(233, 12%, 13%)',
            },
        },
    },
    plugins: [],
}
```

