import React from 'react'
import {ThemeProvider} from './components/themeContext'
import Background from './components/background'
import Layout from './components/layout'

const Dashborder = () => {
  return (
    <div>
        <ThemeProvider>
            <Background>
                <Layout>Dashborder</Layout>
            </Background>
        </ThemeProvider>
    </div>
  )
}

export default Dashborder