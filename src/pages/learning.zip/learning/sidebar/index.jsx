import React from 'react'
import {ThemeProvider} from './components/themeContext'
import Background from './components/background'
import Layout from './components/layout'

const App = () => {
  return (
    <div>
        <ThemeProvider>
            <Background>
                <Layout>ABC</Layout>
            </Background>
        </ThemeProvider>
    </div>
  )
}

export default App