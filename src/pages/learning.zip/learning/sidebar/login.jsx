import React from 'react'
import {ThemeProvider} from './components/themeContext'
import Background from './components/background'
import Layout from './components/layout'

const Login = () => {
  return (
    <div>
        <ThemeProvider>
            <Background>
                <Layout>Signin</Layout>
            </Background>
        </ThemeProvider>
    </div>
  )
}

export default Login