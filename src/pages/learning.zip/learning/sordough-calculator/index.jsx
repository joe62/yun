import React from 'react'

const App = () => {
  return (
    <>
    <header className=' bg-gray-200 px-0 py-10'><h1 className=' m-2.5 text-5xl'>自然发酵面包计算器</h1></header>
    <main className=' bg-gray-300 pt-2.5 pr-0 pb-16 pl-0'>
      <form action="">
        <h3 className='m-2.5'>面粉</h3>
        <input className=' m-1'  type="checkbox" name="flour1" id="wheat" checked />面包粉
        <input className=' inline' type="number" name="flourRatio" id="wheatRatio" min="0" max="100" value="100"/>%<br></br>
        <input type="checkbox" name="flour2" id="spelt" />斯佩尔特小麦粉
        
        <input className='' type="number" name="flourRatio" id="speltRatio" min="0" max="100" value="0"/>%<br></br>
        <input type="checkbox" name="flour3" id="rye"/>黑麦粉
        <input type="number" name="flourRatio" id="ryeRatio" min="0" max="100" value="0"/>%<br/>
            <h3>含水量:</h3>
            <input type="range" name="hydration" id="hydration" value="70" min='0' max="150"
                oninput="hydrationAmountId.value = hydration.value"/>
            <output name='hydrationAmountName' id="hydrationAmountId" value="">70</output>% <br/>
            <h3>酵种:</h3>
            <input type="number" id="starter" step="1"/>%
            <h3>盐:</h3>
            <input type="number" id="salt" step="0.1"/>%
            <h3>数量:</h3>
            <input type="number" name="breadAmount" id="breadAmount" value="2"/>
      </form><br/>
      <button id="calcBtn">计算</button>
      <section id="recipeDisplay">
            <h3>最终配方：</h3>
            <div id="wheatAmount"></div>
            <div id="speltAmount"></div>
            <div id="ryeAmount"></div>
            <div id="waterAmount"></div>
            <div id="starterAmount"></div>
            <div id="saltAmount"></div>
            <br/><p>这是你的面团</p>
        </section>
    </main>
    </>
  )
}

export default App