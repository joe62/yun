import React,{Fragment,useState} from 'react'
import { Dialog, Transition } from '@headlessui/react'

const MyModal = ({isOpen,setOpenModal,setRecipe}) => {
  const [fileName, setFileName]=useState({})
  

  function closeModal(){
    setOpenModal(false)
  }

  function upload(){
    
    const fileReader = new FileReader();
    fileReader.readAsText(fileName, "UTF-8");
    fileReader.onload = e=>{
      const data = JSON.parse(e.target?.result)
    
      setRecipe(data)    
      closeModal()
    }
    
  }
  return (
    <>

    <Transition appear show={isOpen} as={Fragment}>
      <Dialog as='div' className="relative z-10" onClose={closeModal}>
        <Transition.Child
          as={Fragment}
          enter='ease-out duration-300'
          enterFrom='opacity-0'
          enterTo='opacity-100'
          leave='ease-in duration-200'
          leaveFrom='opactity-100'
          leaveTo='opactity-0'
        >
          <div className='fixed inset-0 bg-black bg-opacity-25' />
        </Transition.Child>
        <div>
          <div>
            <Transition.Child
             as={Fragment}
             enter="ease-out duration-300"
             enterFrom="opacity-0 scale-95"
             enterTo="opacity-100 scale-100"
             leave="ease-in duration-200"
             leaveFrom="opacity-100 scale-100"
             leaveTo="opacity-0 scale-95"
            >
              <Dialog.Panel>
                <Dialog.Title>
                导入配方
                </Dialog.Title>
                <input 
                className="w-full mt-2 p-2.5 flex-1 text-white bg-sky-600 rounded-md" 
                type="file" 
                name="fileImport" id="import" accept=".json,application/json"
                onChange={e=>setFileName(e.target.files[0])}
                />
                <div className="items-center gap-12 mt-3 sm:flex">
                <button 
                className=" w-full mt-2 p-2.5 flex-1 text-white bg-sky-600 rounded-md outline-none ring-offset-2 ring-sky-600 focus:ring-2 " 
                type="button"
                onClick={upload}
                >
                  确认
                </button>
                <button 
                className=" w-full mt-2 p-2.5 flex-1 text-white bg-sky-600 rounded-md outline-none ring-offset-2 ring-sky-600 focus:ring-2 "
                type="button"
                onClick={() => closeModal()}
                >取消</button>
              </div>
              </Dialog.Panel>
            </Transition.Child>
          </div>
        </div>
      </Dialog>
    </Transition>
    </>
  )
}

export default MyModal