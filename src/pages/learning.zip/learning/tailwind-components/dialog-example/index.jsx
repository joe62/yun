import React,{useState} from 'react'
import Modal from './fileDialog3'

// const App = () => {
//   const [recipe, setRecipe] = useState()
//   // const GetRecipe=(jsonData)=>{
//   //   setRecipe(jsonData)
//   // }
//   return (
//     <div>
//       <Dialog SetRecipe={setRecipe} />
//       {recipe && <pre><code>{JSON.stringify(recipe,null,2)}</code></pre>}
//     </div>
//   )
// }
const App = ()=>{
  const [recipe, setRecipe] = useState()
  const [isOpen, setIsOpen] = useState(true)

  return (
    <>
        <div className='flex flex-col items-center justify-center h-60'>
      <button 
      type="button"
      onClick={()=>setIsOpen(true)}
      className='px-4 py-2 text-purple-100 bg-purple-600 rounded-sm  hover:bg-purple-300 hover:text-purple-600'
      >导入配方</button>
      <Modal isOpen={isOpen} setOpenModal={setIsOpen} setRecipe={setRecipe} />
    </div>
     
     {recipe && <pre><code>{JSON.stringify(recipe,null,2)}</code></pre>}
    </>
  )
} 

export default App