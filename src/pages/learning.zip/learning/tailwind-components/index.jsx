import React from 'react'
import {DropdownExample1} from './dropdown-example1'
import { DropdownExample2 } from './dropdown-example2'
import { DropdownExample3 } from './dropdown-example3'
import { DropdownExample4 } from './dropdown-example4'

const App = () => {
  return (
    <div>
      <DropdownExample1 />
      <DropdownExample2 />
      <DropdownExample3/>
    </div>
  )
}

export default App